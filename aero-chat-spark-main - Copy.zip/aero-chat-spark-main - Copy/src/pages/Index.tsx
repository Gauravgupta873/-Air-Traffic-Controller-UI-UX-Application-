
import React, { useState } from 'react';
import { motion } from 'framer-motion';
import ParticleBackground from '../components/ParticleBackground';
import Header from '../components/Header';
import Hero from '../components/Hero';
import AuthModal from '../components/AuthModal';
import ChatInterface from '../components/ChatInterface';
import Features from '../components/Features';
import About from '../components/About';
import Contact from '../components/Contact';
import Footer from '../components/Footer';
import LoginPage from '../components/LoginPage';
import UserProfile from '../components/UserProfile';
import { useAuth } from '@/hooks/useAuth';

const Index = () => {
  const [isAuthOpen, setIsAuthOpen] = useState(false);
  const [isChatOpen, setIsChatOpen] = useState(false);
  const [showLoginPage, setShowLoginPage] = useState(false);
  const { user, signOut } = useAuth();

  const handleLogin = (email?: string, password?: string) => {
    setIsAuthOpen(false);
    setShowLoginPage(false);
    setIsChatOpen(true);
  };

  const handleLogout = async () => {
    await signOut();
    setIsChatOpen(false);
  };

  const handleShowLogin = () => {
    setShowLoginPage(true);
    setIsAuthOpen(false);
  };

  if (showLoginPage) {
    return (
      <LoginPage 
        onLogin={handleLogin}
        onClose={() => setShowLoginPage(false)}
      />
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-indigo-900 text-white overflow-hidden">
      <ParticleBackground />
      
      <div className="relative z-10">
        <Header 
          onAuthClick={() => setIsAuthOpen(true)}
          isAuthenticated={!!user}
          onChatClick={() => setIsChatOpen(true)}
          onLoginClick={handleShowLogin}
          onLogout={handleLogout}
          userEmail={user?.email || ''}
        />
        
        {!isChatOpen ? (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.8 }}
          >
            {user && (
              <div className="container mx-auto px-6 pt-32 pb-8">
                <UserProfile userEmail={user.email || ''} onLogout={handleLogout} />
              </div>
            )}
            <Hero onGetStarted={() => setIsAuthOpen(true)} />
            <Features />
            <About />
            <Contact />
            <Footer />
          </motion.div>
        ) : (
          <ChatInterface onClose={() => setIsChatOpen(false)} />
        )}
        
        <AuthModal 
          isOpen={isAuthOpen}
          onClose={() => setIsAuthOpen(false)}
          onLogin={handleLogin}
          onShowLogin={handleShowLogin}
        />
      </div>
    </div>
  );
};

export default Index;
