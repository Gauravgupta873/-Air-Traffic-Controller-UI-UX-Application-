import React from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Plane, MessageCircle, Menu, LogIn, LogOut } from 'lucide-react';
interface HeaderProps {
  onAuthClick: () => void;
  isAuthenticated: boolean;
  onChatClick: () => void;
  onLoginClick: () => void;
  onLogout: () => void;
  userEmail: string;
}
const Header: React.FC<HeaderProps> = ({
  onAuthClick,
  isAuthenticated,
  onChatClick,
  onLoginClick,
  onLogout,
  userEmail
}) => {
  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({
        behavior: 'smooth'
      });
    }
  };
  return <motion.header initial={{
    y: -100,
    opacity: 0
  }} animate={{
    y: 0,
    opacity: 1
  }} transition={{
    duration: 0.6
  }} className="fixed top-0 left-0 right-0 z-50 bg-black/20 backdrop-blur-md border-b border-white/10">
      <div className="container mx-auto px-6 py-4">
        <div className="flex items-center justify-between">
          <motion.div whileHover={{
          scale: 1.05
        }} className="flex items-center space-x-3 cursor-pointer" onClick={() => scrollToSection('top')}>
            <div className="relative">
              <Plane className="h-8 w-8 text-blue-400 transform rotate-45" />
              <div className="absolute -top-1 -right-1 w-3 h-3 bg-green-400 rounded-full animate-pulse"></div>
            </div>
            <div>
              <h1 className="text-xl font-bold bg-gradient-to-r from-blue-400 to-cyan-400 bg-clip-text text-transparent">
                ATC ChatBot
              </h1>
              <p className="text-xs text-gray-400">Air Traffic Control Assistant</p>
            </div>
          </motion.div>

          <div className="hidden md:flex items-center space-x-6">
            <nav className="flex space-x-6">
              <button onClick={() => scrollToSection('features')} className="text-gray-300 hover:text-white transition-colors duration-200 hover:scale-105 transform">
                Features
              </button>
              <button onClick={() => scrollToSection('about')} className="text-gray-300 hover:text-white transition-colors duration-200 hover:scale-105 transform">
                About
              </button>
              <button onClick={() => scrollToSection('contact')} className="text-gray-300 hover:text-white transition-colors duration-200 hover:scale-105 transform">
                Contact
              </button>
            </nav>
            
            <div className="flex space-x-3 items-center">
              {isAuthenticated ? <>
                  <span className="text-sm text-gray-300">
                    Welcome, {userEmail.split('@')[0]}
                  </span>
                  <Button onClick={onChatClick} className="bg-green-600 hover:bg-green-700 text-white px-6 py-2 rounded-full transition-all duration-200 transform hover:scale-105">
                    <MessageCircle className="h-4 w-4 mr-2" />
                    Open Chat
                  </Button>
                  <Button onClick={onLogout} variant="outline" className="border-red-400 text-red-400 hover:bg-red-400 hover:text-white px-4 py-2 rounded-full transition-all duration-200">
                    <LogOut className="h-4 w-4" />
                  </Button>
                </> : <>
                  <Button onClick={onLoginClick} variant="outline" className="border-white/30 hover:bg-white/10 px-6 py-2 rounded-full transition-all duration-200 text-zinc-950">
                    <LogIn className="h-4 w-4 mr-2" />
                    Login
                  </Button>
                  <Button onClick={onAuthClick} className="bg-gradient-to-r from-blue-500 to-cyan-500 hover:from-blue-600 hover:to-cyan-600 text-white px-6 py-2 rounded-full transition-all duration-200 transform hover:scale-105">
                    Get Started
                  </Button>
                </>}
            </div>
          </div>

          <div className="md:hidden">
            <Button variant="ghost" size="sm" className="text-white hover:bg-white/10 hover:scale-105 transform transition-all duration-200">
              <Menu className="h-6 w-6" />
            </Button>
          </div>
        </div>
      </div>
    </motion.header>;
};
export default Header;