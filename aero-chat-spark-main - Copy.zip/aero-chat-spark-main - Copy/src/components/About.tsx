
import React from 'react';
import { motion } from 'framer-motion';
import { Plane, Users, Award, TrendingUp, Clock, Globe } from 'lucide-react';
import { Button } from '@/components/ui/button';

const About = () => {
  const stats = [
    { icon: Plane, value: '50,000+', label: 'Flights Managed', color: 'text-blue-400' },
    { icon: Users, value: '2,500+', label: 'Air Traffic Controllers', color: 'text-green-400' },
    { icon: Award, value: '99.9%', label: 'Uptime Guarantee', color: 'text-yellow-400' },
    { icon: TrendingUp, value: '40%', label: 'Efficiency Improvement', color: 'text-purple-400' }
  ];

  const features = [
    {
      title: 'Advanced AI Technology',
      description: 'Powered by cutting-edge machine learning algorithms for predictive analysis and real-time decision making.',
      icon: '🧠'
    },
    {
      title: 'Global Network Integration',
      description: 'Seamlessly connects with aviation authorities worldwide for comprehensive traffic management.',
      icon: '🌐'
    },
    {
      title: '24/7 Monitoring',
      description: 'Round-the-clock surveillance and support ensuring continuous air traffic safety and efficiency.',
      icon: '⏰'
    }
  ];

  return (
    <section id="about" className="py-20 px-6 bg-gradient-to-b from-slate-900/50 to-blue-900/30">
      <div className="container mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold mb-6 bg-gradient-to-r from-white to-blue-300 bg-clip-text text-transparent">
            About ATC ChatBot
          </h2>
          <p className="text-xl text-gray-300 max-w-4xl mx-auto leading-relaxed">
            Revolutionary AI-powered Air Traffic Control system designed to enhance aviation safety, 
            efficiency, and communication through advanced technology and intelligent automation.
          </p>
        </motion.div>

        {/* Plane Image Section */}
        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          whileInView={{ opacity: 1, scale: 1 }}
          transition={{ duration: 1 }}
          className="relative mb-16 mx-auto max-w-4xl"
        >
          <div className="relative bg-gradient-to-br from-blue-500/20 to-cyan-500/20 rounded-3xl p-8 backdrop-blur-sm border border-white/10">
            <img 
              src="https://images.unsplash.com/photo-1466442929976-97f336a657be?ixlib=rb-4.0.3&auto=format&fit=crop&w=1200&q=80" 
              alt="Air Traffic Control Tower"
              className="w-full h-64 md:h-80 object-cover rounded-2xl shadow-2xl"
            />
            <div className="absolute -top-4 -right-4 bg-gradient-to-r from-blue-500 to-cyan-500 p-4 rounded-2xl">
              <Plane className="h-8 w-8 text-white transform rotate-45" />
            </div>
          </div>
        </motion.div>

        {/* Stats Section */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-16">
          {stats.map((stat, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              whileHover={{ scale: 1.05 }}
              className="bg-white/5 backdrop-blur-sm rounded-2xl p-6 text-center border border-white/10 hover:border-white/20 transition-all duration-300 cursor-pointer"
            >
              <stat.icon className={`h-8 w-8 ${stat.color} mx-auto mb-3`} />
              <div className="text-2xl font-bold text-white mb-1">{stat.value}</div>
              <div className="text-gray-400 text-sm">{stat.label}</div>
            </motion.div>
          ))}
        </div>

        {/* Features Grid */}
        <div className="grid md:grid-cols-3 gap-8 mb-12">
          {features.map((feature, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.2 }}
              whileHover={{ scale: 1.02, y: -5 }}
              className="bg-white/5 backdrop-blur-sm rounded-2xl p-8 border border-white/10 hover:border-blue-400/50 transition-all duration-300 cursor-pointer group"
            >
              <div className="text-4xl mb-4 group-hover:scale-110 transition-transform duration-300">
                {feature.icon}
              </div>
              <h3 className="text-xl font-semibold text-white mb-4 group-hover:text-blue-400 transition-colors duration-300">
                {feature.title}
              </h3>
              <p className="text-gray-400 leading-relaxed">
                {feature.description}
              </p>
            </motion.div>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-center"
        >
          <Button
            size="lg"
            className="bg-gradient-to-r from-blue-500 to-cyan-500 hover:from-blue-600 hover:to-cyan-600 text-white px-8 py-4 rounded-full text-lg font-semibold transition-all duration-300 transform hover:scale-105"
          >
            Learn More About Our Technology
          </Button>
        </motion.div>
      </div>
    </section>
  );
};

export default About;
