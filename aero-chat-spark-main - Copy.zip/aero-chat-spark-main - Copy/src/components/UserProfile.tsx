
import React from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { LogOut, User, Plane, Settings, Activity } from 'lucide-react';

interface UserProfileProps {
  userEmail: string;
  onLogout: () => void;
}

const UserProfile: React.FC<UserProfileProps> = ({ userEmail, onLogout }) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-black/40 backdrop-blur-xl border border-white/20 rounded-2xl p-6 text-white"
    >
      <div className="flex items-center space-x-4 mb-6">
        <div className="relative">
          <div className="w-16 h-16 bg-gradient-to-r from-blue-500 to-cyan-500 rounded-full flex items-center justify-center">
            <User className="h-8 w-8 text-white" />
          </div>
          <div className="absolute -bottom-1 -right-1 w-5 h-5 bg-green-400 rounded-full border-2 border-black animate-pulse"></div>
        </div>
        <div>
          <h3 className="text-xl font-bold">Air Traffic Controller</h3>
          <p className="text-gray-300">{userEmail}</p>
          <div className="flex items-center space-x-2 mt-1">
            <Activity className="h-4 w-4 text-green-400" />
            <span className="text-sm text-green-400">Online</span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4 mb-6">
        <div className="bg-white/5 rounded-lg p-4 text-center">
          <Plane className="h-6 w-6 text-blue-400 mx-auto mb-2" />
          <p className="text-sm text-gray-300">Active Flights</p>
          <p className="text-2xl font-bold text-white">24</p>
        </div>
        <div className="bg-white/5 rounded-lg p-4 text-center">
          <Settings className="h-6 w-6 text-cyan-400 mx-auto mb-2" />
          <p className="text-sm text-gray-300">Clearances</p>
          <p className="text-2xl font-bold text-white">12</p>
        </div>
      </div>

      <Button
        onClick={onLogout}
        variant="outline"
        className="w-full border-red-400 text-red-400 hover:bg-red-400 hover:text-white transition-all duration-300"
      >
        <LogOut className="h-4 w-4 mr-2" />
        Sign Out
      </Button>
    </motion.div>
  );
};

export default UserProfile;
