
import React, { useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { Loader2 } from 'lucide-react';

const AuthCallback = () => {
  const { toast } = useToast();

  useEffect(() => {
    const handleAuthCallback = async () => {
      try {
        const { data, error } = await supabase.auth.getSession();
        
        if (error) {
          console.error('Auth callback error:', error);
          toast({
            title: "Authentication Error",
            description: error.message,
            variant: "destructive",
          });
          // Redirect to login page
          window.location.href = '/';
          return;
        }

        if (data.session) {
          toast({
            title: "Email confirmed!",
            description: "Your email has been confirmed successfully. Welcome!",
          });
          // Redirect to main page
          window.location.href = '/';
        }
      } catch (error) {
        console.error('Unexpected error:', error);
        window.location.href = '/';
      }
    };

    handleAuthCallback();
  }, [toast]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-indigo-900 flex items-center justify-center">
      <div className="text-center text-white">
        <Loader2 className="h-8 w-8 animate-spin mx-auto mb-4" />
        <p>Confirming your email...</p>
      </div>
    </div>
  );
};

export default AuthCallback;
