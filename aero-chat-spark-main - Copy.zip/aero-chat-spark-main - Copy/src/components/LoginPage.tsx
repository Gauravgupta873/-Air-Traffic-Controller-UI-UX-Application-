import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Eye, EyeOff, Lock, Mail, Plane, LogIn, AlertCircle } from 'lucide-react';
import { useAuth } from '@/hooks/useAuth';
interface LoginPageProps {
  onLogin: (email: string, password: string) => void;
  onClose: () => void;
}
const LoginPage: React.FC<LoginPageProps> = ({
  onLogin,
  onClose
}) => {
  const [showPassword, setShowPassword] = useState(false);
  const [isSignUp, setIsSignUp] = useState(false);
  const [formData, setFormData] = useState({
    email: '',
    password: ''
  });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [showConfirmation, setShowConfirmation] = useState(false);
  const {
    signIn,
    signUp,
    loading
  } = useAuth();
  const validateForm = () => {
    const newErrors: Record<string, string> = {};
    if (!formData.email.trim()) {
      newErrors.email = 'Email is required';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      newErrors.email = 'Please enter a valid email';
    }
    if (!formData.password) {
      newErrors.password = 'Password is required';
    } else if (isSignUp && formData.password.length < 6) {
      newErrors.password = 'Password must be at least 6 characters';
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validateForm()) return;
    try {
      if (isSignUp) {
        const {
          error,
          needsConfirmation
        } = await signUp(formData.email, formData.password);
        if (error) {
          if (error.message.includes('already registered')) {
            setErrors({
              email: 'This email is already registered. Try signing in instead.'
            });
          } else {
            setErrors({
              general: error.message
            });
          }
          return;
        }
        if (needsConfirmation) {
          setShowConfirmation(true);
          return;
        }
        onLogin(formData.email, formData.password);
      } else {
        const {
          error
        } = await signIn(formData.email, formData.password);
        if (error) {
          if (error.message.includes('Invalid login credentials')) {
            setErrors({
              general: 'Invalid email or password'
            });
          } else if (error.message.includes('Email not confirmed')) {
            setErrors({
              general: 'Please confirm your email before signing in. Check your inbox!'
            });
          } else {
            setErrors({
              general: error.message
            });
          }
          return;
        }
        onLogin(formData.email, formData.password);
      }
    } catch (error) {
      setErrors({
        general: 'An unexpected error occurred. Please try again.'
      });
    }
  };
  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
    if (errors[field]) {
      setErrors(prev => ({
        ...prev,
        [field]: ''
      }));
    }
    if (errors.general) {
      setErrors(prev => ({
        ...prev,
        general: ''
      }));
    }
  };
  if (showConfirmation) {
    return <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-indigo-900 flex items-center justify-center p-6">
        <motion.div initial={{
        opacity: 0,
        scale: 0.9
      }} animate={{
        opacity: 1,
        scale: 1
      }} className="w-full max-w-md bg-black/40 backdrop-blur-xl border border-white/20 rounded-2xl p-8 text-center">
          <div className="mb-6">
            <Mail className="h-16 w-16 text-blue-400 mx-auto mb-4" />
            <h2 className="text-2xl font-bold text-white mb-2">Check Your Email</h2>
            <p className="text-gray-300">
              We've sent a confirmation link to <strong>{formData.email}</strong>
            </p>
            <p className="text-gray-400 text-sm mt-2">
              Click the link in your email to confirm your account and complete registration.
            </p>
          </div>
          
          <Button onClick={onClose} variant="outline" className="border-white/30 hover:bg-white/10 text-zinc-950">
            Back to Home
          </Button>
        </motion.div>
      </div>;
  }
  return <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-indigo-900 flex items-center justify-center p-6">
      {/* Animated plane background */}
      <div className="absolute inset-0 overflow-hidden">
        <motion.div animate={{
        x: ['-100px', '100vw'],
        y: ['20%', '80%', '20%']
      }} transition={{
        duration: 20,
        repeat: Infinity,
        ease: "linear"
      }} className="absolute opacity-20">
          <Plane className="h-20 w-20 text-blue-400 transform rotate-45" />
        </motion.div>
        <motion.div animate={{
        x: ['100vw', '-100px'],
        y: ['60%', '30%', '70%']
      }} transition={{
        duration: 25,
        repeat: Infinity,
        ease: "linear",
        delay: 5
      }} className="absolute opacity-15">
          <Plane className="h-16 w-16 text-cyan-400 transform -rotate-45" />
        </motion.div>
      </div>

      <motion.div initial={{
      opacity: 0,
      scale: 0.9
    }} animate={{
      opacity: 1,
      scale: 1
    }} transition={{
      duration: 0.5
    }} className="w-full max-w-md bg-black/40 backdrop-blur-xl border border-white/20 rounded-2xl p-8 relative z-10">
        <div className="text-center mb-8">
          <motion.div initial={{
          scale: 0.8,
          opacity: 0
        }} animate={{
          scale: 1,
          opacity: 1
        }} className="flex items-center justify-center space-x-3 mb-4">
            <div className="relative">
              <Plane className="h-10 w-10 text-blue-400 transform rotate-45" />
              <div className="absolute -top-1 -right-1 w-3 h-3 bg-green-400 rounded-full animate-pulse"></div>
            </div>
            <span className="text-3xl font-bold bg-gradient-to-r from-blue-400 to-cyan-400 bg-clip-text text-transparent">
              {isSignUp ? 'Create Account' : 'ATC Login'}
            </span>
          </motion.div>
          <p className="text-gray-300">
            {isSignUp ? 'Join the Air Traffic Control Center' : 'Access Air Traffic Control Center'}
          </p>
        </div>

        {errors.general && <div className="mb-4 p-3 bg-red-500/20 border border-red-500/30 rounded-lg flex items-center space-x-2">
            <AlertCircle className="h-4 w-4 text-red-400" />
            <p className="text-red-400 text-sm">{errors.general}</p>
          </div>}

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-2">
            <Label htmlFor="email" className="text-gray-200">Email Address</Label>
            <div className="relative">
              <Mail className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
              <Input id="email" type="email" placeholder="pilot@atc.com" value={formData.email} onChange={e => handleInputChange('email', e.target.value)} className="pl-10 bg-white/10 border-white/20 text-white placeholder:text-gray-400 focus:border-blue-400" disabled={loading} />
            </div>
            {errors.email && <p className="text-red-400 text-sm">{errors.email}</p>}
          </div>

          <div className="space-y-2">
            <Label htmlFor="password" className="text-gray-200">Password</Label>
            <div className="relative">
              <Lock className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
              <Input id="password" type={showPassword ? 'text' : 'password'} placeholder="Enter your password" value={formData.password} onChange={e => handleInputChange('password', e.target.value)} className="pl-10 pr-10 bg-white/10 border-white/20 text-white placeholder:text-gray-400 focus:border-blue-400" disabled={loading} />
              <button type="button" onClick={() => setShowPassword(!showPassword)} className="absolute right-3 top-3 text-gray-400 hover:text-white transition-colors" disabled={loading}>
                {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
              </button>
            </div>
            {errors.password && <p className="text-red-400 text-sm">{errors.password}</p>}
          </div>

          <Button type="submit" disabled={loading} className="w-full bg-gradient-to-r from-blue-500 to-cyan-500 hover:from-blue-600 hover:to-cyan-600 text-white py-3 rounded-lg font-semibold transition-all duration-300 transform hover:scale-105 disabled:opacity-50 disabled:cursor-not-allowed">
            <LogIn className="h-4 w-4 mr-2" />
            {loading ? 'Please wait...' : isSignUp ? 'Create Account' : 'Access Control Tower'}
          </Button>

          <div className="text-center space-y-2">
            <button type="button" onClick={() => {
            setIsSignUp(!isSignUp);
            setErrors({});
            setFormData({
              email: '',
              password: ''
            });
          }} className="text-blue-400 hover:text-blue-300 transition-colors duration-200" disabled={loading}>
              {isSignUp ? "Already have an account? Sign in" : "Don't have an account? Create one"}
            </button>
            <br />
            <button type="button" onClick={onClose} className="text-gray-400 hover:text-gray-300 transition-colors duration-200" disabled={loading}>
              Back to Home
            </button>
          </div>
        </form>
      </motion.div>
    </div>;
};
export default LoginPage;