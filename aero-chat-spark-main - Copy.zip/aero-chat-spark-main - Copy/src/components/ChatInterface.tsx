
import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Send, Minimize2, X, Plane, Radio, AlertTriangle } from 'lucide-react';

interface Message {
  id: string;
  type: 'user' | 'bot' | 'system';
  content: string;
  timestamp: Date;
}

interface ChatInterfaceProps {
  onClose: () => void;
}

const ChatInterface: React.FC<ChatInterfaceProps> = ({ onClose }) => {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      type: 'system',
      content: 'ATC Control Center Online - All systems operational',
      timestamp: new Date()
    },
    {
      id: '2',
      type: 'bot',
      content: 'Good day, this is ATC ChatBot. I\'m here to assist with air traffic coordination, flight planning, and emergency protocols. How may I help you today?',
      timestamp: new Date()
    }
  ]);
  const [inputValue, setInputValue] = useState('');
  const [isMinimized, setIsMinimized] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSendMessage = () => {
    if (!inputValue.trim()) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      type: 'user',
      content: inputValue,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInputValue('');

    // Simulate bot response
    setTimeout(() => {
      const botMessage: Message = {
        id: (Date.now() + 1).toString(),
        type: 'bot',
        content: generateBotResponse(inputValue),
        timestamp: new Date()
      };
      setMessages(prev => [...prev, botMessage]);
    }, 1000);
  };

  const generateBotResponse = (input: string): string => {
    const lowerInput = input.toLowerCase();
    
    if (lowerInput.includes('weather')) {
      return 'Current weather conditions: Clear skies, visibility 10+ miles, winds 120° at 8 knots, altimeter 30.12. Conditions are favorable for all flight operations.';
    } else if (lowerInput.includes('runway')) {
      return 'Active runways: 24L/06R and 24R/06L. Runway 24L is preferred for departures, 06R for arrivals. Current runway conditions are dry and clear.';
    } else if (lowerInput.includes('emergency')) {
      return '🚨 EMERGENCY PROTOCOL ACTIVATED - Please state the nature of emergency. Emergency services are standing by. Clearing priority airspace now.';
    } else if (lowerInput.includes('clearance')) {
      return 'For flight plan clearance, please provide: Aircraft callsign, aircraft type, departure airport, destination, requested altitude, and route of flight.';
    } else if (lowerInput.includes('traffic')) {
      return 'Current traffic density: Moderate. 12 aircraft in controlled airspace. No conflicts detected. Traffic flow running smoothly with minimal delays.';
    } else {
      return 'Roger that. I\'m processing your request. For specific air traffic control assistance, please provide aircraft details, location, or specify the type of support you need.';
    }
  };

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString('en-US', { 
      hour12: false, 
      hour: '2-digit', 
      minute: '2-digit' 
    });
  };

  if (isMinimized) {
    return (
      <motion.div
        initial={{ scale: 0, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        className="fixed bottom-6 right-6 z-50"
      >
        <Button
          onClick={() => setIsMinimized(false)}
          className="bg-blue-600 hover:bg-blue-700 text-white p-4 rounded-full shadow-lg"
        >
          <Radio className="h-6 w-6" />
        </Button>
      </motion.div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.8 }}
      animate={{ opacity: 1, scale: 1 }}
      className="fixed inset-4 z-50 bg-slate-900/95 backdrop-blur-xl rounded-2xl border border-white/20 shadow-2xl flex flex-col"
    >
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b border-white/20">
        <div className="flex items-center space-x-3">
          <div className="relative">
            <Plane className="h-6 w-6 text-blue-400 transform rotate-45" />
            <div className="absolute -top-1 -right-1 w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
          </div>
          <div>
            <h2 className="text-lg font-semibold text-white">ATC Control Center</h2>
            <p className="text-sm text-green-400 flex items-center">
              <div className="w-2 h-2 bg-green-400 rounded-full mr-2 animate-pulse"></div>
              Online - All Systems Operational
            </p>
          </div>
        </div>
        
        <div className="flex space-x-2">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setIsMinimized(true)}
            className="text-gray-400 hover:text-white hover:bg-white/10"
          >
            <Minimize2 className="h-4 w-4" />
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={onClose}
            className="text-gray-400 hover:text-white hover:bg-white/10"
          >
            <X className="h-4 w-4" />
          </Button>
        </div>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        <AnimatePresence>
          {messages.map((message) => (
            <motion.div
              key={message.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className={`flex ${message.type === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              <div className={`max-w-xs lg:max-w-md px-4 py-2 rounded-2xl ${
                message.type === 'user' 
                  ? 'bg-blue-600 text-white ml-12' 
                  : message.type === 'system'
                  ? 'bg-yellow-600/20 text-yellow-300 border border-yellow-600/50'
                  : 'bg-white/10 text-white mr-12'
              }`}>
                {message.type === 'bot' && (
                  <div className="flex items-center mb-2">
                    <Radio className="h-4 w-4 text-blue-400 mr-2"  />
                    <span className="text-xs text-blue-400 font-medium">ATC Bot</span>
                  </div>
                )}
                {message.type === 'system' && (
                  <div className="flex items-center mb-2">
                    <AlertTriangle className="h-4 w-4 text-yellow-400 mr-2" />
                    <span className="text-xs text-yellow-400 font-medium">System</span>
                  </div>
                )}
                <p className="text-sm">{message.content}</p>
                <p className="text-xs opacity-60 mt-1">{formatTime(message.timestamp)}</p>
              </div>
            </motion.div>
          ))}
        </AnimatePresence>
        <div ref={messagesEndRef} />
      </div>

      {/* Input */}
      <div className="p-4 border-t border-white/20">
        <div className="flex space-x-2">
          <Input
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
            placeholder="Type your message to ATC..."
            className="flex-1 bg-white/10 border-white/20 text-white placeholder:text-gray-400 focus:border-blue-400"
          />
          <Button
            onClick={handleSendMessage}
            disabled={!inputValue.trim()}
            className="bg-blue-600 hover:bg-blue-700 text-white px-4"
          >
            <Send className="h-4 w-4" />
          </Button>
        </div>
        <p className="text-xs text-gray-400 mt-2">
          Available commands: weather, runway, traffic, clearance, emergency
        </p>
      </div>
    </motion.div>
  );
};

export default ChatInterface;
